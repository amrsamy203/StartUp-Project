import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForOf } from '@angular/common';
import {Http} from '@angular/http';
import { AuthService } from './auth.service';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  ms = '';
  messages = [];
  users = [];
  project;
  path = 'http://localhost:3000';
  constructor(public http1: Http, private http: HttpClient, public authService: AuthService) { }
  getPerProfile(id) {
    return this.http.get(this.path + '/Preprofile/' + id);
  }
  ///////////////
  PerprofileUser(PerprofileData, id) {
    this.http.post<any>(this.path + '/Perprofile/' + id, PerprofileData).subscribe(res => {
    });
  }
  //////////////////////
  getMessages(userId) {
    this.http.get<any>(this.path + '/posts/' + userId).subscribe(res => {
      this.messages = res;
    });
  }
  postMessage(message) {
    this.http.get(this.path + '/posts', message).subscribe(res => {
    });
  }
  getUsers() {
    this.http.get<any>(this.path + '/users').subscribe(res => {
      this.users = res;
    });
  }
  getProfile() {
    return this.http.get<any>(this.path + '/profile/' + this.authService.ms);
  }
  getID() {
    this.http.get<any>(this.path + '/Perprofile').subscribe(res => {
      this.ms = res;
      console.log(res);
    });
  }
  //////////////////////////
  sendNewProjectData(newProjectData) {
    this.http.post<any>('http://localhost:3000/new-project', newProjectData).subscribe(res => {
    });
  }
  getProject(id: string) {
    this.http1.get('http://localhost:3000/view-project/' + id).subscribe(res => {
      this.project = res.json();
    });
  }
   ////////////////////////
}
