import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-person',
  templateUrl: './home-person.component.html',
  styleUrls: ['./home-person.component.css']
})
export class HomePersonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
