export interface Terms {
  type: string;
  subject: string;
  details: string;
}
