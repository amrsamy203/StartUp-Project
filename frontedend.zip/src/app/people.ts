export interface People {
  name: string;
  rule: string;
  about: string;
  profile: string;
  prev_projects: string;
}
